Step to run

#### Install Docker

```
curl -s https://get.docker.com/ | sudo sh -
```

Please figure out by yourself if you are using Windows or MacOs for installing docker and docker-compose.

#### Deploy
```
cd pentestlab
sudo docker compose up -d
```

