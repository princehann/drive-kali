  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    body {
      padding-bottom: 70px; /* Adjust as needed to prevent the footer from overlapping content */
    }
    .footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      background-color: #f8f9fa; /* Bootstrap's background color for light theme */
      text-align: center;
      padding: 10px;
    }
  </style>